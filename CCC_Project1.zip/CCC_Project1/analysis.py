#!/usr/bin/python

import matplotlib
matplotlib.use('Agg')

import couchdb
import matplotlib.pyplot as plt
from time import sleep
couch = couchdb.Server('http://couchdbadmin:***********@45.113.235.12:5984')
db = couch['tweetsdb']


keywords = ['commercialistic','materialistic','philistine','philistinism','desireous','eager','desire','itchy','lickerish','miserly','hoggish','hogging','hogger','piggish','eager','hungry','impatient','rapacious','selfish','acquisitive','avaricious','avid','carnivorous','close','close-fisted'
,'covetous'
,'craving'
,'desirous'
,'devouring'
,'edacious'
,'esurient'
,'gluttonous'
,'gobbling'
,'gormandizing'
,'grabby'
,'grasping'
,'grudging'
,'gulping'
,'guzzling'
,'hoggish'
,'insatiable'
,'insatiate'
,'intemperate'
,'itchy'
,'miserly'
,'niggardly'
,'omnivorous'
,'parsimonious'
,'pennypinching'
,'penurious'
,'piggish'
,'prehensile'
,'ravening'
,'ravenous'
,'stingy'
,'swinish'
,'tight'
,'tight-fisted'
,'voracious'
,'factotum'
,'grind'
,'laborer'
,'menial'
,'peon'
,'plodder'
,'servant'
,'toiler'
,'worker'
,'workhorse'
,'nose to grindstone'
,'working','worker','hardworker','hard worker']

save_results_to = '/var/www/html/'

au_id= 'managersEarning1000_1249'

doc2 = db[au_id]
mgrs=[]
hours=[]
for y in doc2:
	if y == "_id":
		continue
	elif y == "_rev":
		continue
	else:
		mgrs.append(y)
		hours.append(doc2[y])
	
plt.clf()
plt.plot(hours, mgrs)
plt.savefig(save_results_to + 'aurin.png')


days = ['Mon' , 'Tue' , 'Wed', 'Thu' , 'Fri' , 'Sat' , 'Sun']
day=[]
Values=[0,0,0,0,0,0,0]
while True:
	doc_id = 'tweets'
	if doc_id in db:
		doc = db[doc_id]
	else:
		db[doc_id] = {}
		doc = db[doc_id]
	for x in doc:
		for word in keywords:
			if word in doc[x][1]:			
				day = doc[x][0][:3]
				if day in days:
					y = days.index(day)
					Values[y] = Values[y] + 1
					plt.clf()
					plt.plot(days, Values)
					plt.savefig(save_results_to + 'foo.png')
					sleep(100)
					break
