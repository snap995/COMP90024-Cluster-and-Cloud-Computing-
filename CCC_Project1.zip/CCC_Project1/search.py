#!/usr/bin/python

import tweepy
import couchdb
from datetime import datetime
from time import sleep
ckey = ""
csecret = ""
atoken = ""
asecret = ""
couch = couchdb.Server("http://couchdbadmin:***********@45.113.235.12:5984")
db = couch['tweetsdb']

cred = db["credentials"]

ckey = cred["ckey"]
csecret = cred["csecret"]
atoken = cred["atoken"]
asecret = cred["asecret"]

doc_id = 'tweets'
auth = tweepy.OAuthHandler(ckey, csecret)
auth.set_access_token(atoken, asecret)

if doc_id in db:
	doc = db[doc_id]
else:
	db[doc_id] = {}
	doc = db[doc_id]
		
api = tweepy.API(auth)

query = '*'
max_tweets = 100
running = True
delay = 900
megadelay = 1500
i = 0
while running:
	try:
		searched_tweets = [ status for status in tweepy.Cursor(api.search, q=query,geocode="-37.6390981,145.0434407,10km").items(max_tweets)]		
		if searched_tweets == []:
			running = False
			print("stopping")
		else:
			for tweet in searched_tweets:
					if (tweet.lang) == "en":
						doc[tweet.id] = [tweet.created_at.strftime("%d-%b-%Y (%H:%M:%S.%f)") , tweet.text]
						db.save(doc)
			print(" ran" ,i, "th time")
			i = i+1
			sleep(delay)
						
	except BaseException as e:
		sleep(megadelay)
