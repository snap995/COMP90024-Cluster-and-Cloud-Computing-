#!/usr/bin/python

from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import couchdb
from time import sleep
ckey = ""
csecret = ""
atoken = ""
asecret = ""
couch = couchdb.Server('http://couchdbadmin:***********@45.113.235.12:5984')
db = couch['tweetsdb']

cred = db["credentials"]

ckey = cred["ckey"]
csecret = cred["csecret"]
atoken = cred["atoken"]
asecret = cred["asecret"]
AUS_GEO_CODE = [113.03, -39.06, 154.73, -12.28]
running = True
delay = 10
doc_id = 'tweets'
if doc_id in db:
	doc = db[doc_id]
else:
	db[doc_id] = {}
	doc = db[doc_id]



class listener (StreamListener):
	def on_data(self, data):
		id = data.split(',"id":')[1].split(',"id_str"')[0]
		date = data.split('"created_at":"')[1].split('","id"')[0]
		text = data.split(',"text":"')[1].split('","display_text_range"')[0].split('","source"')[0]
		try:
			doc[id] = [date , text]
			db.save(doc)
			print('ran')
		except BaseException as e:
			print('error getting data')
			sleep(delay)
			
print('authorizing')	
try:	
	auth = OAuthHandler(ckey, csecret)
	auth.set_access_token(atoken, asecret)
	print('done')
	twitterStream = Stream(auth, listener())
	twitterStream.filter(locations=AUS_GEO_CODE)
except BaseException as e:
	print('error authorizing')
	sleep(delay)
	twitterStream = Stream(auth, listener())
	twitterStream.filter(locations=AUS_GEO_CODE)