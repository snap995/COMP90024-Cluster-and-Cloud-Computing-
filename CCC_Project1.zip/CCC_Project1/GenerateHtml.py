#!/usr/bin/python

import webbrowser, os
webbrowser.open('file:///home/Deadlysins/Website/index.html')